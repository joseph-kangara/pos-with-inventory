<?php
session_start();
include('../connect.php');
	
	//$result = $db->prepare("SELECT * FROM products");
		$result = $db->prepare("SELECT * FROM products ");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
			$availableqty=$row['qty'];
    }
      
	

if(isset($_POST['submit'])){
$a = $_POST['code'];

$d = $_POST['price'];

$f = $_POST['qty'];
$g = $_POST['o_price'];
$j = $_POST['left'];




//$j = $f + $availableqty;


// query

$sql1 = mysqli_query($con,"INSERT INTO  stocked (product_name,selling_price,qty_added,original_price,new_qty) VALUES ('$a','$d','$f','$g','$j') ");
$sql = mysqli_query($con,"UPDATE products SET product_code='$a',price='$d',qty_sold='$f',o_price='$g',qty='$j' WHERE product_code = '$a' ");
if ($sql) {
  # code...
header("location:products.php");
// queryecho $f.'';
// queryecho $availableqty.'';
// queryecho $j;
}

else{
  echo 'failed'.mysqli_error($con);
}
}


?>



