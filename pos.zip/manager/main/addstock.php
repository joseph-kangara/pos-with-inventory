<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="savestock.php" method="post" enctype="multipart-form/data">
<center><h4><i class="icon-plus-sign icon-large"></i> Add Stock</h4></center>
<hr>
<div id="ac">


<span>Product Name : </span>
<select placeholder="select product" name="code" style="width:265px;height:30px " required>

<option style="width:265px; height:30px;">Click to select</option>
			
			?>

	<?php
	include('../connect.php');
	//$result = $db->prepare("SELECT * FROM products");
		$result = $db->prepare("SELECT *, price * qty as total FROM products ORDER BY product_id DESC");
		$result->bindParam(':userid', $res);
		$result->execute();
		for($i=0; $row = $result->fetch(); $i++){
			$availableqty=$row['qty'];
      
      
	?>
		<option style="width:265px; height:30px;" name ="code"value="<?php echo $row['product_code'];?>"><?php echo $row['product_code']; ?></option>
	<?php
				}
			?>


</select><br>



<!--<span>Brand Name : </span><input type="text" style="width:265px; height:30px;" name="code" ><br>-->
<span>Selling Price : </span><input type="text" id="txt1" style="width:265px; height:30px;" name="price" required><br>
<span>Original Price : </span><input type="text" id="txt2" style="width:265px; height:30px;" name="o_price" required><br>
<span>Add Quantity : </span><input type="number" style="width:265px; height:30px;" min="0" id="txt11" name="qty" required><br>
<span>Total Qty : </span><input type="number" style="width:265px; height:30px;" min="0" step="0.5" id="txt11" name="left" required><br>

<span></span><input type="hidden" style="width:265px; height:30px;" id="txt22" name="qty_sold" Required ><br>
<div style="float:right; margin-right:10px;">
<button name="submit" class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Save</button>
</div>
</div>
</form>
