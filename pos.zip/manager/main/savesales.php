<?php
session_start();

include('../connect.php');
$a = $_POST['invoice'];
$b = $_POST['cashier'];
$c = $_POST['date'];
$d = $_POST['pt'];
$e = $_POST['amount'];
$z = $_POST['profit'];
$cname = $_POST['cname'];
if($d=='credit') {
$f = $_POST['due'];
$sql = "INSERT INTO sales (invoice_number,cashier,type,amount,profit,due_date,name) VALUES (:a,:b,:d,:e,:z,:f,:g)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':d'=>$d,':e'=>$e,':z'=>$z,':f'=>$f,':g'=>$cname));
header("location: preview.php?invoice=$a");
exit();
}
if($d=='cash') {
$f = $_POST['cash'];
$h = $_POST['code'];
$sql = "INSERT INTO sales (invoice_number,cashier,type,amount,profit,due_date,name,code) VALUES (:a,:b,:d,:e,:z,:f,:g,:h)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a,':b'=>$b,':d'=>$d,':e'=>$e,':z'=>$z,':f'=>$f,':g'=>$cname,'h'=>$h));
header("location: preview.php?invoice=$a");
exit();
}
// query



?>